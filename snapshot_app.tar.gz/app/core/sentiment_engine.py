from typing import Optional
from app.utils.text_utils import normalize_text


class SentimentEngine:
    """
    Motor único de análisis de sentimiento.
    Compatible con Python 3.9.
    """

    def __init__(self, model_path: str, vectorizer_path: Optional[str], model_name: str):
        self.model_path = model_path
        self.vectorizer_path = vectorizer_path
        self.model_name = model_name

        # Placeholder realista (modelo dummy por ahora)
        self.model = None
        self.vectorizer = None

    def analyze(self, text: str) -> dict:
        clean_text = normalize_text(text)

        # Lógica temporal (dummy) — luego se conecta ML real
        if any(word in clean_text for word in ["bueno", "excelente", "rápido", "profesional"]):
            sentiment = "positivo"
            confidence = 0.90
        elif any(word in clean_text for word in ["malo", "lento", "terrible"]):
            sentiment = "negativo"
            confidence = 0.85
        else:
            sentiment = "neutral"
            confidence = 0.60

        return {
            "texto": text,
            "sentimiento": sentiment,
            "confianza": confidence,
            "explicacion": f"Análisis ejecutado por {self.model_name}"
        }


# Instancia única (motor único empresarial)
_engine = SentimentEngine(
    model_path="models/default.pkl",
    vectorizer_path=None,
    model_name="motor-unico-v1"
)


def analyze_text(text: str) -> dict:
    return _engine.analyze(text)
